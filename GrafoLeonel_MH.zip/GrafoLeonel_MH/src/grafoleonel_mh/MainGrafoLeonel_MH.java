/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Main.java to edit this template
 */
package grafoleonel_mh;
import java.util.Scanner;

/**
 *
 * @author Matos
 */
public class MainGrafoLeonel_MH {
    public static void main(String[] args) {
        Scanner nom = new Scanner(System.in);
        int ini;
        int opc;
        do{
            System.out.print("1. Crear Grafo");
            if(g != null){
                System.out.println("""
                                   2. Inserta Nodos
                                   3. Agregar Arista
                                   4. Imprimir Adyacencia
                                   5. Imprimir matriz de adyacencia
                                   6. Recorrido a Profundidad
                                   7. Recorrido en Anchura
                                   """);
            }
            System.out.println("0. Salir");
            System.out.println("Dame la opcion a realizar: ");
            opc = nom.nextInt();
            switch(opc){
                case 1:
                    System.out.println("Dame el Tamano del Grafo");
                    int tam = opc = nom.nextInt();
                    g = new Grafo(tam);
                    break;
                case 2:
                    g.addNodos();
                    break;
                case 3:
                    System.out.println("Dame el Indice del Nodo");
                    for(int ind = 0; ind < g.numNodos; ind ++){
                        System.out.println(ind + "-> Nodo " + g.nodos[ind]);
                    }
                    System.out.println("Dame el nodo A: ");
                    int nodoA = nom.nextInt();
                    System.out.println("Dame nodo B: ");
                    int nodoB = opc = nom.nextInt();
                    
                    System.out.println("Dame el peso :");
                    int peso = nom.nextInt();
                    
                    if(!g.addArista(nodoA, nodoB, peso)){
                        System.out.println("Error al insertar Arista");
                    }
                    break;
                case 4:
                    // g. add
            }
        }
    }
}
    

/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package grafoleonel_mh;

/**
 *
 * @author Matos
 */
public class ColaLeonel_MH {
    Nodo ini;
    
    public void encolar(){
        
    }
    
    public int desencolar(){
        return 1;
    }
    
    public boolean isEmpty(){
        return true;
    }   
}

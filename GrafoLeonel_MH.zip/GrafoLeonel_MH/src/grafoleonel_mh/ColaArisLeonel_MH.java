/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package grafoleonel_mh;

/**
 *
 * @author Matos
 */
public class ColaArisLeonel_MH {
    Lista lista;
    
    public ColaAris(){
        lista = new Lista();
    }
    
    boolean isEmpty(){
        return lista.isEmpty();
    }
    
    public void encolar(Arista dato){ // No devuelve nada y pide una Arista
        lista.insertarUlt(dato);// Insertamos al último la Arista
    }
    
    public Arista desencolar(){
        return lista.getPrim(); // Siempre que se quita un elemento se retorna
    }
    
    public void ordenar(){
        
    }
    
    public void actualiza(int nodoIni, int nodoFin, int peso){
        Arista nodo = lista.getElem(nodoIni);
        
        if(nodo != null){
            if(nodo.peso == -1 || nodo.peso > peso){
                nodo.peso = peso;
            }
            lista.insertar(nodo);
        }
    }
    
}

/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package grafoleonel_mh;

/**
 *
 * @author Matos
 */
public class ListaLeonel_MH {
    NodoArisLeonel_MH ini; // necesitamos un nodo inicial
    
    public ListaLeonel_MH(){ // el CONSTRUCTOR es para inicializar
        ini = null;
    }
    
    boolean isEmpty(){
        if(ini == null){
            return true;
        }
        return false;
    }
    
    public void insertar(Arista dato){ // Para insertar al principio
        
    }
    
    public void insertarUlt(Arista dato){ // Para insertar Aristas
        
    }
    
    public Arista getPrim(){ // Devuelve una arista
        return ini.dato;
    }
    
    public Arista getElem(int ind){ // Eliminar por posición (Elemento)
        NodoAris aux, aux2;
        if(isEmpty() == false){
            return null;
        }
        aux = ini;
        if(ini.dato.nodoIni = ind){
            ini = ini.sig;
            return aux.dato;    
        }
        
        while(aux.sig != null && aux.sig.dato.nodoIni != ind){
            aux = aux.sig; // Sirve para recorrer
        }
        
        if(aux.sig != null){
            aux2 = aux.sig;
            aux.sig = aux2.sig;
            return aux2.dato;
        }
        return null;
    }
    
    public int getTam(){
        int tam = 0;
        NodoAris aux;
        if(isEmpty() == false){
            aux = ini;
            tam ++;
            while(aux != null){
                aux = aux.sig;
                tam ++;
            }
        }
        return tam;
    }
    
    public void ordenar(){
        int ind;
        if(isEmpty() == false){
            if(ini.sig != null){
                for(ind = 0; ind < tam; ind ++){
                    NodoAris aux;
                    Arista auxAris;
                    aux ini;
                    while(aux.sig != null){
                        if(aux.dato.peso == -1 && aux.sig.dato.peso != -1 || aux.dato.peso > aux.sig.dato.peso)){
                            auxAris = aux.dato;
                            aux.dato = aux.sig.dato;
                            aux.sig.dato = auxAri;
                        }
                    }
                }
            }
        }
    }
    
    public void mostrar(){
        NodoArisLeonel_MH aux;
        if(isEmpty() == false){
            aux = ini;
            System.out.println(ini.dato.nodoFin + ", " + ini.dato.peso + "-> ");
            while(aux !=  null){
                aux = aux.sig;
                System.out.println(ini.dato.nodoFin + ", " + ini.dato.peso + "-> ");
            }
        }
    }
    
}

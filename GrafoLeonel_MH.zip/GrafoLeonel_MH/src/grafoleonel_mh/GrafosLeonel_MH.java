/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package grafoleonel_mh;
import java.util.Scanner;


/**
 *
 * @author Matos
 */
public class GrafosLeonel_MH {
    int matriz[][];
    String nombres[];
    int numNodos;
    int visitados[];
    
    public Grafos(int numNodos){
        this.numNodos = numNodos;
        matriz = new int[numNodos][numNodos];
        nombres = new String[numNodos];
        initGrafos();
    }
    
    public void initGrafos(){
        for(int fila=0; fila<numNodos; fila++){
            for(int cola=0; cola<numNodos; cola++){
                matriz[fila][cola]=-1;
            }
        }
    }
    
    public void setNombres(){
        int pos;
        String nodo;
        Scanner entrada = new Scanner(System.in);
        for(pos = 0; pos<numNodos; pos++){
            System.out.println("Agrega Nodo " + (pos + 1));
            nodo = entrada.nextLine();
            nombres[pos]=nodo;
        }
    }
    
    public boolean setArista(String nodoA, String nodoB){
        int ind;
        int indNodoA = -1;
        int indNodoB = -1;
        
        for(ind=0; ind<numNodos; ind++){
            if(nombres[ind] == nodoA){
                indNodoA = ind;
            }
            if(nombres[ind] == nodoB){
                indNodoB = ind;
            }
        }
        if(indNodoA != -1 && indNodoB != -1){
            matriz[indNodoA][indNodoB] = 1;
            matriz[indNodoB][indNodoA] = 1;
            return true;
        }
        return false;
    }
    
    public boolean addArista(int nodoA, int nodoB, int peso){
        if(nodoA >= 0 && nodoA < numNodos && nodoB >= 0 && nodoB < numNodos){
            matriz[nodoA][nodoB] = peso;
            matriz[nodoB][nodoA] = peso;
        }
        return false;
    }
    
    public void imprimirMAdy(){
        for(int fila = 0; fila < numNodos; fila ++){
            System.out.print(fila + "\t");
            for(int col = 0; col < numNodos; col ++){
                System.out.print(matriz[fila][col] + "\t");
            }
            System.out.println("");
        }
    }
    
    public void recoAnchura(){
        while(cola.isEmpty() != true){
            int nodo = cola.desencolar();
            System.out.println(nombres[nodo] + "-->");
            for(int ind=0; ind<numNodos; ind++){
                if(matriz[nodo][ind]==1){
                    if(visitados[ind]!=1){
                        cola.encolar(ind);
                        visitados[ind]=1;
                    }
                }
            }
        }
    }
    
    public int buscaInd(String nodo){
        return 0; // Busca la cadena y retorna el índice para buscar después en el 
    }
    
    public void muestraProc(Lista proc){
        
    }
    
    public void dijkstra (int nodoIni){
        ColaAris noProc = new ColaAris(); // La Cola de NO PROCESADOS
        Lista Proc = new Lista(); // Lista de PROCESADOS
        int ind;
        Arista aux;
        for(ind = 0; ind < numNodos; ind ++){
            if(ind == nodoIni){
                noProc.encolar(new Arista(ind, -1, 0));
            } else {
                noProc.encolar(new Arista(ind));
            }
            noProc.ordenar();
            aux = noProc.desencolar();
            /* Idea del profe
            while(aux != null){
                Proc.insertar(aux);
                for(ind = 0; ind <numNodos; ind++){
                    if(matriz[nodoIni][ind] > 0){ // Si hay adyacencia se busca en la LISTA de NO PROCESADOS
                        noProc.actualiza(nodoIni, ind, (nodoFin,aux.peso + matriz[nidiIni][ind])); // Buscar elemento a elemento si tenemos el nodo inicial y verificamos el peso que tenga
                    }
                }
                noProc.ordenar();
                aux = noProc.desencolar();
            }
            */
            
            // Idea del Compañero
            while(noProc.isEmpty() == false){
                aux = noProc.desencolar();
                Proc.insertar(aux);
                for(ind = 0; ind <numNodos; ind++){
                    if(matriz[nodoIni][ind] > 0){ // Si hay adyacencia se busca en la LISTA de NO PROCESADOS
                        noProc.actualiza(nodoIni, ind, (aux.peso + matriz[nodoIni][ind])); // Buscar elemento a elemento si tenemos el nodo inicial y verificamos el peso que tenga
                    }
                }
                noProc.ordenar();
            }
            proc.mostrar();
        }
    }
    
    public void agregarNodos(){
        int ind;
        Scanner cad = new Scanner(System.in);
        for(ind = 0; ind < numNodos; ind ++){
            System.out.println("Dame nodo " + ind);
            nombres[ind] = cad.nextLine();
        }
    } 
}
